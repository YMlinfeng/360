import copy
import os
import json
import torch
from torch.utils.data import Dataset
from torchvision.datasets.utils import download_url
from torchvision import transforms
#from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from torchvision.transforms.functional import InterpolationMode
from einops import rearrange
from random import choice
from PIL import Image
import torchvision.transforms as T

import gzip
from io import BytesIO
import base64
from torch.utils.data import  IterableDataset
import random
import pdb
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
from torch.utils.data import DataLoader

def default_train(n_px):
    return [
        T.Lambda(lambda img: img.convert('RGB')),
        T.Resize(n_px),  # Image.BICUBIC
        T.RandomCrop(n_px),
        # T.RandomHorizontalFlip(),
        T.ToTensor(),
        T.Normalize([0.5], [0.5]),
    ]
                                                                                                                                                                                                

def list_all_files(rootdir):
    _files = []
    for item in os.walk(rootdir):
        if item[2]:
            for sub in item[2]:
                _files.append(os.path.join(item[0],sub))
    return _files

class Ablation_dataset(IterableDataset):
    def __init__(self, 
            image_list_txt = [],
            transform='default_train',
            resolution=256,
            load_vae_feat=False,
            mask_ratio=0.0,
            mask_type='null',
            proportion_empty_prompts=0.1,
            **kwargs) -> None:
        super().__init__()
        self.sub_path_list = []
        for txt in [
                    #'/home/jovyan/boomcheng-data-shcdt/chengbo/datasets/ablation_data/flux_gen_grit/ablation_data_flux_grit_gen_traindata_200w.txt',
                    #'/home/jovyan/boomcheng-data-shcdt/chengbo/datasets/ablation_data/flux_gen_mix_GritLaion/ablation_data_flux_mixup_traindata_200w.txt',
                    #'/home/jovyan/boomcheng-data-shcdt/chengbo/datasets/ablation_data/natural_grit/ablation_data_nature_grit_traindata_200w.txt',
                    #'/home/jovyan/boomcheng-data-shcdt/chengbo/datasets/ablation_data/natural_laion/ablation_data_nature_laion_traindata_200w.txt',
                    '/home/jovyan/boomcheng-data-shcdt/chengbo/datasets/ablation_data/mixup_FluxGen_NatureGritLaion/ablation_data_GenNat_mix_traindata_200w.txt',
                   ]:#'Aigc_list_9000w.txt', 'Aigc_laion.txt'
            with open(txt, 'r') as f:
                sub_path_list = f.read().strip().split('\n')
                self.sub_path_list.extend(sub_path_list)
                
        output=[]
        for i in range(1000):
            random.shuffle(self.sub_path_list)
            output+=self.sub_path_list
        self.sub_path_list=output
        
        self.resolution = resolution
        self.proportion_empty_prompts=proportion_empty_prompts
        self.image_transform = transforms.Compose(default_train(self.resolution))

        print (self.sub_path_list[:2])
        self.mult_GPU=True
        self.rank_res = 0
        self.world_size = 1
        try:
            self.rank_res = int(os.environ.get('RANK'))
            self.world_size = int(os.environ.get('WORLD_SIZE'))
            print('word_size, ', self.world_size)
            print('rank_res, ', self.rank_res)
            print('file_num, ', len(self.sub_path_list))
            #worker_info = torch.utils.data.get_worker_info()
            #print ('worker_info num_workers/id, ', worker_info.num_workers, worker_info.id)
        except Exception as e:
            self.mult_GPU=False
            print('mult_GPU Error', e)
            
    def tokenize_captions(self, examples):        
        captions = []
        captions.append(examples["caption"])
        clip_inputs = self.tokenizer_clip(
            captions, max_length=self.tokenizer_clip.model_max_length, padding="max_length", truncation=True, return_tensors="pt"
        )
        return clip_inputs.input_ids


    def _sample_generator(self, intval_num):
        worker_info = torch.utils.data.get_worker_info()
        #pdb.set_trace()
        for file_index in range(len(self.sub_path_list)):
            sub_path = self.sub_path_list[file_index]
            #pdb.set_trace()
            #print ("----------------------------------------------")
            #print (worker_info)
            #print (file_index, sub_path)
            
            succ = 0
            #if True:
            if file_index % (self.world_size*worker_info.num_workers) == worker_info.num_workers * intval_num + worker_info.id:                            
                #if not os.path.isfile(sub_path):
                #    print ("***************", sub_path)
                #    continue
               
                data_info = {'img_hw': torch.tensor([self.resolution, self.resolution], dtype=torch.float32),
                    'aspect_ratio': torch.tensor(1.)}
                
                if 'journeydb' in sub_path:
                    try:
                        with open(sub_path) as fr:
                            data = json.load(fr)
                        for item in data:
                            try:
                                img_path = os.path.join('/home/jovyan/diffusion-data-cephfs-new/liushanyuan/data/JourneyDB/OpenDataLab___JourneyDB/raw/JourneyDB/train/imgs/', item['img_path'])
                                img_path = img_path.replace('.png', '.jpg') #img_path[:-4]+'.jpg'
                                #if random.random() < 0.5:
                                #    prompt = item['prompt']
                                #else:
                                try:
                                    prompt = item['Task2']['Caption']
                                except Exception as e:
                                    print (e, sub_path)
                                    prompt = item['prompt']
                                img = Image.open(img_path)
                                img = self.image_transform(img)

                                if random.random() < self.proportion_empty_prompts:
                                    prompt = ""
                                yield (img, prompt)
                                #return (img, prompt, data_info)
                                succ = 1
                                #break
                            except Exception as e:
                                print (e, sub_path)
                    except Exception as e:
                        print (e)
                elif "flux_gen_grit" in sub_path or "FLUX" in sub_path:
                    try:
                        with open(sub_path, "r") as fr:
                            for line in fr:
                                linesp = line.strip().split("#;#")
                                imgid, img_path, img_info = linesp

                                img_info = eval(img_info)
                                prompt = img_info["en_caption"]
                                visual_quality_score = img_info["visual_quality_score"]

                                #if "FLUX" in sub_path and  float(visual_quality_score) < 6.0:
                                #        continue

                                img = Image.open(img_path)
                                img = self.image_transform(img)

                                if random.random() < self.proportion_empty_prompts:
                                    prompt = ""

                                yield (img, prompt)
                    
                    except Exception as e:
                        print (e, sub_path)

                elif "natural_grit" in sub_path:
                    try:
                        root_image_grit = "/home/jovyan/liushanyuan-sh-ceph-new/data/"
                        with open(sub_path) as fr:
                            data_dict = json.load(fr)

                        for k, dot in data_dict.items():
                            #_key, _w, _h, _path_image, caption_base_en, caption_base_cn, caption_long_en, caption_long_cn = dot
                            caption_base_en, caption_base_cn, _w, _h, _path_image, caption_long_en, caption_long_cn = dot
                            if random.random() <= 0.5:
                                prompt = caption_base_en
                            else:
                                prompt = caption_long_en

                            path_image = os.path.join(root_image_grit, _path_image)
                            try:
                                img = Image.open(path_image)
                            except Exception as e:
                                print (e, path_image)
                                continue
                            base_w, base_h = img.size
                            if min(base_w, base_h) < self.resolution:
                                continue
                            img = self.image_transform(img)

                            if random.random() < self.proportion_empty_prompts:
                                prompt = ""
                            yield (img, prompt)

                    except Exception as e:
                        print (e, sub_path)

                elif "laion_2b_200w" in sub_path:
                    try:
                        with open(sub_path, "r") as fr:
                            for line in fr:
                                linesp = line.strip().split("#;#")
                                imgid, img_path, img_info = linesp

                                
                                img_info = eval(img_info)
                                if random.random() <= 0.5:
                                    prompt = img_info["en_caption"] # long
                                else:
                                    prompt = img_info["title"]  # short

                                visual_quality_score = img_info["visual_quality_score"]

                                if float(visual_quality_score) < 5.5:
                                    continue

                                img = Image.open(img_path)
                                img = self.image_transform(img)

                                if random.random() < self.proportion_empty_prompts:
                                    prompt = ""

                                yield (img, prompt)

                    except Exception as e:
                        print (e, sub_path)

                           

            
    #def __getitem__(self, idx):
    def __iter__(self):
        #pdb.set_trace()
        sample_iterator = self._sample_generator(self.rank_res)
        return sample_iterator

    def __len__(self):
        #if self.args.resolution == 512:
        #    return int(488e6) 
        #else:
        #    return int(76e6)
        return int(2e8*100)

def collate_fn(examples):                                                                                                                                                                                     
    img = torch.stack([example[0] for example in examples])
    img = img.to(memory_format=torch.contiguous_format).float()
    prompt = [example[1] for example in examples]
    return {
        "pixel_values": img, 
        'prompts': prompt
    }

# dataset = Ablation_dataset(resolution=256, proportion_empty_prompts=0.1)

# if 1:
#     cnt = 0
#     for res in dataset:
#         cnt += 1
#         print (cnt, res[1])
#         if cnt > 10:
#             break

# if 0:
#     #for ii in range(len(dataset)):
#     for ii in range(0, 10):
#         #pdb.set_trace()
#         #meta_data = dataset[ii]
#         #print (meta_data[1])
#         #dataset.next()
#         image, meta_data = dataset[ii]
#         #print (meta_data)
#         #pdb.set_trace()
#         print ("+++++", ii, meta_data)

# if 0:
#     train_dataloader = DataLoader(#torch.utils.data.DataLoader(
#         dataset,
#         #shuffle = True,
#         #collate_fn = collate_fn,
#         batch_size = 8,
#         num_workers = 8,
#         #pin_memory=True
#     )

#     for step, (x_images, x_prompts) in enumerate(train_dataloader):
#         print (step, x_images.shape, x_prompts)
#         #pdb.set_trace()
#         if step > 20:
#             break


