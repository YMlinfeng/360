#!/bin/bash

# 遍历从epoch_1到epoch_19的目录
for epoch_dir in $(seq 178 -1 169); do
    model_path="checkpoint-${epoch_dir}"
    sh infer.sh "$model_path" 5
done
